sap.ui.define(["sap/suite/ui/generic/template/lib/AppComponent"], function(AppComponent) {
    return AppComponent.extend("ztravel183sar.Component", {
        metadata: {
            manifest: "json"
        }
    });
});
